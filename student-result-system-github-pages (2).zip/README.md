# Student Result Management System

## Publish with GitHub Pages
1. Create a GitHub repository (for GitHub Free, use a public repository).
2. Upload `index.html` to the repository root.
3. Open Settings > Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select `main` and `/ (root)`, then Save.
6. Wait for deployment and open the URL shown in the Pages section.

The website is a static browser application. It stores records in the current browser's local storage. It does not provide secure shared storage, user accounts, or synchronization between devices. Do not enter real identifiable student records on a public demo. For a real school deployment, add a secure backend, authentication, role-based access, backups, and privacy controls.
